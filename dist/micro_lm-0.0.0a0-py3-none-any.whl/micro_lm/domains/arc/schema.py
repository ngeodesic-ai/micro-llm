ARC_LABELS = {
    "count_objects",
    "extend_pattern",
    "flip_tile",
}
