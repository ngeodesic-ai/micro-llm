from .entry import main  # for console_script and -m package use
